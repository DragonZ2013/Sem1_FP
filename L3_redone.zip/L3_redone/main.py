from UI.Menu import menu

def main():
    menu()

main()