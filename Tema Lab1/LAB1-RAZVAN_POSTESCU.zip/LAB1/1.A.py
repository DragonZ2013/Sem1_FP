n = input("n= ")
n = int (n)


for i in range(2, n):
    ok=1
    for j in range (2,i):
        if (i % j) == 0:
             ok=0
             break
    if ok!=0:
        print(i, " ")
