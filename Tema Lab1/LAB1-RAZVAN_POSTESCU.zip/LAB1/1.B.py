len=1
lenn=1
n=int(input("numarul de elemente din vector= "))
l=[]
for i in range(n):
    l.append(int(input()))
for i in range(n-1):
    if l[i]<l[i+1]:
        len=len+1
    else:
        if len>lenn:
            lenn=len
        len=1
if len>lenn:
    lenn=len
print(lenn," ")


