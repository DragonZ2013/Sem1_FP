n = input("n= ")
n = int (n)
i = 0
ok = 0
x = 2
while i < n:
    ok=0
    while ok == 0:
        j = 2
        ok = 1
        while j<=x/2 and ok == 1:
            if (x % j) == 0:
                 ok=0
            j=j+1
        if ok!=0:
            print(x, " ")
            i=i+1
        x=x+1


