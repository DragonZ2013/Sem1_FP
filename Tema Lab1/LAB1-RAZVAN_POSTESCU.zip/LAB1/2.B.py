def cmmdc(a,b):
    while (a!=b):
        if(a>b):
            a=a-b
        else:
            b=b-a
    return a

len=1
lenn=1
n=int(input("numarul de elemente din vector= "))
l=[]
for i in range(n):
    l.append(int(input()))
for i in range(n-1):
    if cmmdc(l[i],l[i+1])==1:
        len=len+1
    else:
        if len>lenn:
            lenn=len
        len=1
if len>lenn:
    lenn=len
print(lenn," ")


